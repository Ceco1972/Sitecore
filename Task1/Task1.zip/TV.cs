﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tasks
{
    class TV : Furniture
    {
        public bool TVOn { get; set; } = true;
        public override string Name
        {
            get { return "TV"; }
        }

        public override void Move()
        {
            string name = this.Name;

        }

        public override void TurnOff ()
        {
            this.TVOn = false;
            Console.WriteLine("TV is turned off");
        }
    }
}
