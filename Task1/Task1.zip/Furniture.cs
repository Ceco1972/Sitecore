﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tasks
{
    public abstract class Furniture 
    {

        public abstract void Move();
        public abstract string Name { get; }
        public virtual void TurnOff()
        {
            Console.WriteLine("Turn it off");
        }
    }


}
