﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tasks
{
    public class Bed : Furniture
    {
        public override string Name
        {
            get { return "Bed"; }
        }

        public override void Move()
        {
            string name = this.Name;
                
        }
    }
}
