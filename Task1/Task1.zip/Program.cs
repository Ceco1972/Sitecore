﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Tasks
{
    /*Random moving furniture
Topics: Inheritance, polymorphism, generic, collections, 
Implement a simple C# console application. Idea is to have a collection of furniture, which can be moved. Each object should have an appropriate method (public interface) for moving. Note that some objects can have additional methods, for a TV it will be turn on/turn off etc. Create a collection of objects and move them in a random position in a foreach. 

Additional notes:
1. It should be easy to add a new object without changing too much code.
2. There should a check that we can add only an object that has the X, Y properties and the Move method.
3. Consider using a loop to move all the objects.
4. The UI must be as simple as possible.A console application with text output is the best solution
5. Add a few additional rooms.Each room must have a name. Consider storing rooms in a dictionary with the name as a key and the room as a value.
6. The TV needs to be turned off before it can be moved. */
    class Program
    {
        public static Dictionary<string, int> Items = new Dictionary<string, int>();

        static void Main(string[] args)
        {
            ICollection<Furniture> myFurniture = new Collection<Furniture>();

            Items.Add("Livingroom", 0);
            Items.Add("Bedroom", 0);

            Console.WriteLine("Choose items (Bed, Couch) for moving.\n\rWrite End if finished. ");
            
            string item = Console.ReadLine();
            while(item!="End"||item!="end")
            {
                switch(item.ToLower())
                {
                    case "bed":
                        Bed mybed = new Bed();
                        myFurniture.Add(mybed);
                        //mybed.Move();
                        break;
                    case "couch":
                        Couch mycouch = new Couch();
                        myFurniture.Add(mycouch);
                        //mycouch.Move();
                        break;
                    case "tv":
                        TV myTv = new TV();
                        myFurniture.Add(myTv);
                        break;
                    default:
                        throw new InvalidOperationException($"Command with name: {item} doesn't exist!");


                }
                Console.WriteLine("Choose items (Bed, Couch, TV) for moving.\n\rWrite End if finished. ");
                item = Console.ReadLine();
                if (item.ToLower() == "end")
                {
                    break;
                }
            }

            foreach(var item1 in myFurniture)
            {
                if (item1.Name == "TV")
                {
                    item1.TurnOff();
                    Items["Livingroom"]++;
                    item1.Move();
                    Console.WriteLine($"{item1.Name} is moved to the Livingroom.");
                    Console.WriteLine();
                }
                if (item1.Name == "Couch")
                {
                    Items["Livingroom"]++;
                    item1.Move();
                    Console.WriteLine($"{item1.Name} is moved to the Livingroom.");
                    Console.WriteLine();
                }
                if (item1.Name == "Bed")
                {
                    Items["Bedroom"]++;
                    item1.Move();
                    Console.WriteLine($"{item1.Name} is moved to the Bedroom.");
                    Console.WriteLine();
                }
            }

            Console.WriteLine($"Bedroom has {Items["Bedroom"]} item(s) moved in.");
            Console.WriteLine($"Livingroom has {Items["Livingroom"]} items moved in.");

        }
    }
}
